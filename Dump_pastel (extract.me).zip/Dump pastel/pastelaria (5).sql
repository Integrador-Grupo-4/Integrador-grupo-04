CREATE DATABASE  IF NOT EXISTS `pastelaria_grupoeduardogabrielgustavojoaoluan_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pastelaria_grupoeduardogabrielgustavojoaoluan_db`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: pastelaria_grupoeduardogabrielgustavojoaoluan_db
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_comanda`
--

DROP TABLE IF EXISTS `tb_comanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_comanda` (
  `id_comanda` int NOT NULL AUTO_INCREMENT,
  `data_assinatura` date DEFAULT NULL,
  `status_pagamento` text,
  `status_comanda` text,
  `cliente_id` int DEFAULT NULL,
  `funcionario_id` int DEFAULT NULL,
  PRIMARY KEY (`id_comanda`),
  KEY `fk_clienteComanda` (`cliente_id`),
  KEY `fk_funcionarioComanda` (`funcionario_id`),
  CONSTRAINT `fk_clienteComanda` FOREIGN KEY (`cliente_id`) REFERENCES `tb_cliente` (`id_cliente`),
  CONSTRAINT `fk_funcionarioComanda` FOREIGN KEY (`funcionario_id`) REFERENCES `tb_funcionario` (`id_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_comanda`
--

LOCK TABLES `tb_comanda` WRITE;
/*!40000 ALTER TABLE `tb_comanda` DISABLE KEYS */;
INSERT INTO `tb_comanda` VALUES (1,'0000-00-00','pago','fechado',1,NULL),(2,'0000-00-00','pago','fechado',2,NULL),(3,'0000-00-00','pago','fechado',3,NULL),(4,'0000-00-00','pago','fechado',4,NULL),(5,'0000-00-00','pago','fechado',5,NULL),(6,'0000-00-00','aberto','aberto',6,NULL),(7,'0000-00-00','aberto','aberto',7,NULL),(8,'0000-00-00','aberto','aberto',8,NULL),(9,'0000-00-00','aberto','aberto',9,NULL),(10,'0000-00-00','aberto','aberto',10,NULL),(11,'0000-00-00','aberto','aberto',11,NULL),(12,'0000-00-00','aberto','aberto',12,NULL),(13,'0000-00-00','aberto','aberto',13,NULL),(14,'0000-00-00','aberto','aberto',14,NULL),(15,'0000-00-00','aberto','aberto',15,NULL),(16,'0000-00-00','atrasado','Atrasado',16,NULL),(17,'0000-00-00','atrasado','Atrasado',17,NULL),(18,'0000-00-00','atrasado','Atrasado',18,NULL),(19,'0000-00-00','atrasado','Atrasado',19,NULL),(20,'0000-00-00','atrasado','Atrasado',20,NULL);
/*!40000 ALTER TABLE `tb_comanda` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-30 14:46:17
