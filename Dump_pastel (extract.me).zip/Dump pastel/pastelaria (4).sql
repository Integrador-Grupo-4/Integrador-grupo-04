CREATE DATABASE  IF NOT EXISTS `pastelaria_grupoeduardogabrielgustavojoaoluan_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pastelaria_grupoeduardogabrielgustavojoaoluan_db`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: pastelaria_grupoeduardogabrielgustavojoaoluan_db
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_cliente`
--

DROP TABLE IF EXISTS `tb_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `cpf` char(11) DEFAULT NULL,
  `senha` varchar(200) DEFAULT NULL,
  `compra_fiado` text,
  `data_fiado` date DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cliente`
--

LOCK TABLES `tb_cliente` WRITE;
/*!40000 ALTER TABLE `tb_cliente` DISABLE KEYS */;
INSERT INTO `tb_cliente` VALUES (1,'Allan','05606971973','senhafacil','Não',NULL),(2,'Arthur','04906751973','senhafacil','Não',NULL),(3,'Jadson','03507287226','senhafacil','Não',NULL),(4,'Mario','07202587823','senhafacil','Não',NULL),(5,'Luigi','08605187316','senhafacil','Não',NULL),(6,'Judson','06305187316','senhafacil','sim',NULL),(7,'Lucas','0860427316','senhafacil','sim',NULL),(8,'Lidia','07605187352','senhafacil','sim',NULL),(9,'Ana','04605187316','senhafacil','sim',NULL),(10,'Carla','09605187316','senhafacil','sim',NULL),(11,'Mirim','08608187316','senhafacil','sim',NULL),(12,'Robson','08606187316','senhafacil','sim',NULL),(13,'Marcos','08605187316','senhafacil','sim',NULL),(14,'Gilberto','08605187316','senhafacil','sim',NULL),(15,'Martha','08605187316','senhafacil','sim',NULL),(16,'Luiz','08605187316','senhafacil','sim',NULL),(17,'Hector','08605187316','senhafacil','sim',NULL),(18,'Junior','08605187316','senhafacil','sim',NULL),(19,'Julia','08605187316','senhafacil','sim',NULL),(20,'Lilian','08605187316','senhafacil','sim',NULL);
/*!40000 ALTER TABLE `tb_cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-30 14:46:17
